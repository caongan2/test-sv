<?php

namespace App\Http\Controllers;

use Barryvdh\DomPDF\Facade\Pdf;
use ConvertApi\ConvertApi;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

class PDFController extends Controller
{
    public function view(){
        $data = $this->getData();
        return view('welcome', ['data' => $data]);
    }

    public function renderPDF(){
        $data = $this->getData();
        $pdf = Pdf::loadView('welcome', ['data' => $data]);
        return $pdf->download('welcome.pdf');
    }

    public function mappingKey(){
        $data = $this->getData();
        $return = [];
        foreach ($data['data'] as $key => $item){
            $return[] = [
                'title' => $item['title'] ?? '',
                'key' => $key
            ];
        }
        return view('html', ['data' => $return]);
    }

    public function getData(){
        $callAPI = Http::withHeaders([
            'Authorization' => 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjYsInJvbGUiOiJBRE1JTiIsImlhdCI6MTY5ODAzMzMwOCwiZXhwIjoxNzAwNjI1MzA4fQ.xSHz8XvZgNvVczE6Ac_XOIklYj8inzYFVoYqZhKUc2M'
        ])->get('https://api.tracuuthansohoconline.com/api/user/look-up/534c8365-f429-41de-b0e2-826712dc04de');
        $data = $callAPI->json();
        $title = $data['data']['data'];
        $count = 1;
        foreach ($title as $key => $item){
            if (isset($item['title'])){
                if ($count <= 6){
                    $data['data']['data'][$key]['page'] = 2;
                }
                if ($count > 6 && $count <= 13){
                    $data['data']['data'][$key]['page'] = 3;
                }
                if ($count > 13){
                    $data['data']['data'][$key]['page'] = 4;
                }
            }
            $count++;
        }
        $data['data']['dateOfBirth'] = Carbon::create($data['data']['dateOfBirth'])->format('d/m/Y');
        return $data['data'];
    }
}
