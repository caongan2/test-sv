<div class="t m0 xb h5 y60 ff2 fs2 fc2 sc0 ls0 ws0">Copyright 2023 - tracuuthansohoc.com - <?php echo e($name); ?>, <?php echo e($date); ?>

</div>
<?php /**PATH /var/www/html/resources/views/footer.blade.php ENDPATH**/ ?>